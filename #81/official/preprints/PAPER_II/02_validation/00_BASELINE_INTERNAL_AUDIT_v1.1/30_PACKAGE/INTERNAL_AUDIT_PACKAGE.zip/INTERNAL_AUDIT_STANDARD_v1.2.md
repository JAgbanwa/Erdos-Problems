# Papers I--III internal audit standard

**Protocol version:** 1.2  
**Audit class:** internal, author-side, non-independent  
**Applies to:** `PAPER_I`, `PAPER_II`, and `PAPER_III` active
`preprint_draft_v1.1` packages  
**Overall verdicts:** `PASS`, `CONDITIONAL_PASS`, `FAIL`, `INCONCLUSIVE`

## 1. Purpose and boundary

This audit is the common author-side gate before the independent adversarial
audit. It checks the frozen manuscript package, the mathematical exposition,
bounded falsification evidence, the correspondence with the packaged Lean
surface, the recorded formal-build evidence, the bilingual publication
artifacts, and the internal prior-art/novelty assessment.

The internal auditor is not independent of the project. A `PASS` under this
standard means that no blocking defect remains within this internal scope. It
does not mean peer review, independent reproduction, external prior-art
clearance, or public-release approval.

### Deliberate non-rebuild rule

The internal audit **must not rerun Lean**. It reviews the already frozen build
record: target metadata, manifests, commands, exit codes, complete build log,
theorem-level axiom output, and escape-hatch scan. A clean rebuild from the
archive, fresh theorem elaboration, and independent `#print axioms` execution
belong to the later external adversarial audit.

## 2. Frozen target and change control

At audit start, record:

- exact manuscript and artifact filenames and SHA-256 values;
- `SOURCE_MANIFEST.sha256` and `PACKAGE_MANIFEST.sha256` hashes;
- freeze metadata, Lean toolchain, Mathlib revision, and recorded build time;
- auditor identity, independence class, host environment, and timestamps;
- the exact audit commands, scripts, ranges, seeds, and exit codes.

Any correction changes the target. After a correction, regenerate affected
artifacts and hashes, record the change, and rerun the affected gate plus every
downstream gate. Evidence from different targets may not be merged silently.

## 3. Required blocking gates

| Gate | Required review | PASS condition |
|---|---|---|
| `G0 TARGET` | File inventory, hashes, freeze metadata, source/package manifests | Target is complete, internally consistent, and unambiguously frozen |
| `G1 CLAIMS` | Definitions, theorem statements, hypotheses, constants, exceptional cases, proof dependencies, scope, and claim map | Every headline and proof-critical claim is covered with no unresolved semantic mismatch |
| `G2 MATHEMATICS` | Independent algebraic recomputation; exact or bounded small-instance/boundary falsification; branch and assumption checks | All exact checks pass; bounded searches find no counterexample and are labelled as bounded evidence |
| `G3 FORMAL-CONFORMANCE` | Static manuscript-to-Lean statement matching, theorem-name matching, dependency tracing, premise/byproduct classification | Manuscript claims match packaged declarations and no hidden project premise or cross-paper dependency is found |
| `G4 RECORDED-BUILD` | Review only of frozen build/axiom/escape-hatch records and their hashes; no Lean execution | Recorded build exit is zero, log reports success, headline declarations have the claimed footprint, and scans show no prohibited escape hatch |
| `G5 BILINGUAL` | English/Spanish semantic comparison, headings, theorem numbering, formulas, tables, figures, citations, formal identifiers, and status language | No protected mathematical or formal content changes across languages |
| `G6 TEX-PDF` | Local-template match, TeX hygiene, two-pass provenance, embedded fonts, full-page rendering, figures, tables, references, margins, glyphs, and cross-references | Both language PDFs are readable, style-matched, traceable to final TeX, and visually defect-free |
| `G7 PRIOR-ART` | Internal literature dossier, exact novelty scope, open-problem status, citations, search date/corpus, and overclaim check | Internal novelty wording is supported and explicitly distinguished from the still-required independent literature gate |
| `G8 PACKAGE` | Directory structure, README/status consistency, integrity manifests, evidence index, report synchronization, and open external gates | Package is reproducible as an internal audit record and does not imply public-release readiness |

## 4. Evidence rules

Each gate must have an `AUDIT_RECORD.md` under
`02_validation/01_INTERNAL_AUDITS/20_EVIDENCE/<GATE_ID>/` containing target
hashes, scope, method, observations, limitations, findings, and verdict.
Machine-executed gates must additionally retain the exact script or command,
full stdout/stderr with exit code, and a machine-readable `summary.json`.
Human/static-review gates may use a complete checklist instead of executable
code, but must identify every source inspected. Each admitted gate has a
`SHA256_MANIFEST.txt`.

Computational search is corroboration, not a proof of an unbounded statement.
Exact symbolic identities may be recorded as exact checks; finite enumeration
must state its domain; randomized checks must state seed and trial count.

## 5. Finding and correction discipline

Findings use `BLOCKER`, `MAJOR`, `MINOR`, or `NOTE`.

- `BLOCKER` and `MAJOR` findings prevent `PASS`.
- A corrected finding remains in the audit trail with before/after hashes and
  the rerun evidence.
- Editorially safe corrections may be applied directly and logged.
- A correction that would change a theorem, assumption, constant, proof step,
  or novelty scope creates a new mathematical target and requires owner review;
  it may not be silently repaired by the auditor.
- `PASS` requires every blocking gate to be `PASS`, zero unresolved
  `BLOCKER`/`MAJOR` findings, and no hidden `NOT_RUN` surface.

## 6. Prior art and novelty language

The internal gate may conclude that no earlier result was identified within
its documented corpus. It must not state that no such result exists. The
manuscript must identify the exact contribution, distinguish the solved split
or fractional subproblem from the still-open full chordal problem, and retain
the independent specialist literature review as a release gate.

## 7. Common outputs

Each paper produces the same output set:

- `INTERNAL_AUDIT_FINAL_REPORT.md` -- semantic source of truth;
- `INTERNAL_AUDIT_FINAL_REPORT.tex` and `.pdf` -- synchronized report;
- `INTERNAL_AUDIT_SUMMARY.json` -- gate verdicts and counters;
- `INTERNAL_AUDIT_SHA256.txt` -- admitted report/evidence hashes;
- one evidence directory and manifest per gate;
- `INTERNAL_AUDIT_PACKAGE.zip` plus its SHA-256 sidecar.

The final report states corrections made, residual non-blocking risks, open
external gates, and one of the allowed overall verdicts. A certificate or
public-release recommendation is outside this internal standard.

## 8. Sequential execution rule

Audit Paper I to closure before starting Paper II; audit Paper II to closure
before starting Paper III. After all three individual `PASS` verdicts, perform
a cross-paper consistency check covering terminology, result dependencies,
version/status language, bibliography scope, formal interfaces, and release
structure.


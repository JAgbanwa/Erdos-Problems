# Papers I--III internal audit standard

**Protocol version:** 1.3  
**Audit class:** internal, author-side, non-independent  
**Applies to:** `PAPER_I`, `PAPER_II`, and `PAPER_III` active
`preprint_draft_v1.2` packages  
**Overall verdicts:** `PASS`, `CONDITIONAL_PASS`, `FAIL`, `INCONCLUSIVE`

## 1. Purpose and boundary

This is the common author-side gate before independent adversarial audit. It
checks each frozen manuscript package, mathematical exposition, bounded
falsification evidence, packaged Lean correspondence, recorded formal-build
evidence, bilingual publication artifacts, and internal prior-art assessment.
It is not peer review, independent reproduction, external novelty clearance,
or public-release approval.

### Deliberate non-rebuild rule

The internal audit does not rerun a full Lean build. It reviews the frozen
target metadata, manifests, commands, exit codes, complete recorded logs,
theorem-level axiom output, and escape-hatch scans. A clean extraction and
rebuild are reserved for external adversarial audit. A narrowly scoped axiom
query may be rerun only when repairing the audit surface itself, and must be
identified separately from the recorded full build.

## 2. Frozen target and change control

At audit start record exact manuscript/artifact hashes, formal archive name and
SHA-256, source/package manifests, freeze metadata, Lean toolchain and Mathlib
revision, recorded build details, auditor class, commands, scripts, ranges,
seeds, and exit codes. Any correction changes the target: regenerate the
Markdown-to-TeX-to-PDF chain, QA the rendered PDFs, regenerate hashes, and
rerun the affected and downstream gates. Evidence from different targets may
not be merged silently.

## 3. Required blocking gates

| Gate | Required review | PASS condition |
|---|---|---|
| `G0 TARGET` | Inventory, hashes, metadata, manifests, archive sidecars, line endings | Every declared/delivered target exists; all hashes verify portably; target is unambiguous |
| `G1 CLAIMS` | Definitions, statements, hypotheses, constants, boundary regimes, proof dependencies, claim map | Every headline/proof-critical claim is covered with no semantic mismatch |
| `G2 MATHEMATICS` | Independent algebra, exact/bounded boundary falsification, exceptional cases | Exact checks pass and bounded searches find no counterexample within their stated domain |
| `G3 FORMAL-CONFORMANCE` | Exact Lean names/namespaces, statement matching, dependency/classification, axiom-gate coverage | Every claim-map surface exists and every claimed axiom surface is explicitly queried and recorded |
| `G4 RECORDED-BUILD` | Frozen build, supplementary-build, axiom and escape-hatch records; no full rebuild | All manuscript-named files/logs exist, hashes agree, recorded exits are zero, and prohibited escape hatches are absent |
| `G5 BILINGUAL` | EN/ES headings, numbering, formulas, tables, figures, citations, identifiers, status and provenance | Protected mathematical/formal content and artifact provenance agree across languages |
| `G6 TEX-PDF` | Template, TeX hygiene, two-pass provenance, fonts, all-page render, figures/tables/references/margins/glyphs | Both PDFs derive from final TeX and are structurally and visually defect-free |
| `G7 PRIOR-ART` | Internal dossier, precise novelty scope, open-status wording, citations, corpus/date, overclaim | Internal wording is supported and independent literature review remains an explicit external gate |
| `G8 PACKAGE` | Structure, status/README consistency, manifests, evidence/report synchronization, compiler residue | Package is internally reproducible, contains no stray output directories/files, and does not imply release readiness |

## 4. Mandatory provenance regressions

The following checks are blocking because they escaped the preceding internal
standard:

1. Every formal archive filename and SHA-256 printed in Markdown, TeX, or PDF
   must name the archive actually delivered in the same package.
2. Every formal directory and build-log path printed in a manuscript must
   exist in the delivered package; aggregate and supplementary logs must not be
   conflated.
3. Publication hash sidecars must be UTF-8/ASCII with LF terminators and must
   verify all six MD/TeX/PDF artifacts with a standard `sha256sum -c`-equivalent
   parser.
4. The claim map must use exact Lean declarations and namespaces. Every
   headline or protocol-required declaration must occur in both the axiom-query
   source and its recorded output.
5. Boundary-language changes must have a focused regression test for the
   exceptional/equality cases they describe.
6. No shell-variable-named directory (for example `$o` or `$out`) and no TeX
   auxiliary/compiler file may remain in a publication package.

## 5. Evidence and finding rules

Each gate has an `AUDIT_RECORD.md` under
`02_validation/01_INTERNAL_AUDITS/20_EVIDENCE/<GATE_ID>/`, recording target,
scope, method, observations, limitations, findings, and verdict. Executed gates
also retain the exact script/command, full output with exit code, and JSON where
appropriate. Each gate receives a `SHA256_MANIFEST.txt` at sealing.

Findings use `BLOCKER`, `MAJOR`, `MINOR`, or `NOTE`. `BLOCKER` and `MAJOR`
prevent `PASS`. Corrected findings remain in the audit trail with before/after
identity and rerun evidence. Any change to a theorem, assumption, constant,
proof step, or novelty scope creates a new mathematical target and requires
owner review. Computational search is corroboration, not an unbounded proof.

## 6. Prior art and novelty language

The internal gate may say that no earlier result was identified in its
documented corpus; it may not claim that none exists. Each paper must state its
exact contribution, distinguish its solved subproblem from the open full
chordal problem, and retain independent specialist review as an external gate.

## 7. Common outputs

Each paper produces synchronized MD/TeX/PDF final reports, a JSON summary,
per-gate evidence/manifests, `INTERNAL_AUDIT_SHA256.txt`, and a sealed
`INTERNAL_AUDIT_PACKAGE.zip` with sidecar. The report lists corrections,
residual risks, and open external gates. A public-release certificate is out of
scope.

## 8. Sequential execution

Close Paper I before Paper II, and Paper II before Paper III. Once all three
are `PASS`, perform a cross-paper consistency check covering terminology,
dependencies, version/status language, bibliography scope, formal interfaces,
package provenance, and release structure.
